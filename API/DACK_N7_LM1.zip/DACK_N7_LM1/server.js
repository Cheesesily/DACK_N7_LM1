const fs = require('fs')
const bodyParser = require('body-parser')
const jsonServer = require('json-server')
const jwt = require('jsonwebtoken')

const server = jsonServer.create()

const router = jsonServer.router('./db.json')

const db = JSON.parse(fs.readFileSync('./db.json', 'UTF-8'))

const middlewares = jsonServer.defaults();
const PORT = process.env.PORT || 3000;


server.use(middlewares);


server.use(jsonServer.defaults());
server.use(bodyParser.urlencoded({extended: true}))
server.use(bodyParser.json())

const SECRET_KEY = '123456789'
const expiresIn = '1h'

function createToken(payload) {
    return jwt.sign(
        payload, 
        SECRET_KEY, 
        {expiresIn})
}

function verifyToken(token) {
    return jwt.verify(
        token, 
        SECRET_KEY,  
        (err, decode) => decode !== undefined ?  decode : err)
}

function isAuthenticated({email, password}){
    return db.users.findIndex(user => (user.email === email || user.phone === email) && user.password === password) !== -1
}

/** End Setup */

/** Register, Login and Auth */

server.post('/register', (req, res) => {
const {name, email, phone, password} = req.body;

exist_user = db.users.findIndex(x => x.email === email)
if(exist_user !== -1) {
    return res.status(401).json({
    status: 401,
    message: "Email already in use!",
    })
}

exist_user = db.users.findIndex(x => x.phone === phone)
if(exist_user !== -1) {
    return res.status(401).json({
    status: 401,
    message: "Phone number already in use!",
    })
}

const new_user = {
    'id': db.users.length+1,
    name,
    email,
    phone,
    password
}

db.users.push(new_user);
fs.writeFileSync('./db.json', JSON.stringify(db), () => {
    if (err) return console.log(err);
    console.log('writing to ' + fileName);
})
res.status(201).json({
    status: 201,
    message: "Success",
    data: new_user
})
})

//login
server.post('/login', (req, res) => {
    // const {email, password} = req.body
    const email = req.body.email
    const password = req.body.password

    if (isAuthenticated({email, password}) === false) {
    const status = 401
    const message = 'Incorrect email or password'
    res.status(status).json({status, message})
    return
    }
    const access_token = createToken({email, password})
    res.status(200).json({
    status: 200,
    message: "Success",
    data: {
        access_token
    }
    })
})

server.use('/auth',(req, res, next) => {
if (req.headers.authorization == undefined || req.headers.authorization.split(' ')[0] !== 'Bearer') {
    const status = 401
    const message = 'Bad authorization header'
    res.status(status).json({status, message})
    return
}
try {
    let verifyTokenResult;
    verifyTokenResult = verifyToken(req.headers.authorization.split(' ')[1]);

    if (verifyTokenResult instanceof Error) {
        const status = 401
        const message = 'Error: access_token is not valid'
        res.status(status).json({status, message})
        return
    }
    next()
} catch (err) {
    const status = 401
    const message = 'Token đã hết hạn'
    res.status(status).json({status, message})
}
})

/** End */

/** Users */

//view all users
server.get('/auth/users', (req, res) => {
res.status(200).json({
    status: 200,
    data: {
    "users" : db.users
    }
})
})

//Xem thông tin user theo email
server.get('/auth/users/:email', ((req, res)=> {
//let userdb = JSON.parse(fs.readFileSync('./database.json', 'UTF-8'));
    const email = req.params.email;

    const exist_email = db.users.findIndex(user =>  user.email == email || user.phone == email)
    const result = db.users.filter(user =>  user.email == email || user.phone == email)
    if (exist_email !== -1)
    {
        const status = 200
        return res.status(status).json({status, result})
    } else {
    return res.status(401).json({
    status: 401,
    message: "Can't find user!!",
    })
}}))

//delete user by email/phone (whatever it is)
server.delete('/auth/users/:email', (req, res) => {
const email = req.params.email

const exist_email = db.users.findIndex(user =>  user.email == email || user.phone == email)
if(exist_email !== -1) {
    db.users.splice(exist_email, 1);

    fs.writeFileSync('./db.json', JSON.stringify(db), () => {
    if (err) return console.log(err);
    console.log('writing to ' + fileName);
    })

    return res.status(204).json({
    status: 204,
    message: "Success",
    })
} else {
    return res.status(401).json({
    status: 401,
    message: "Can't find user!!",
    })
}

})

//update user
server.patch('/auth/users/:email', (req, res) => {
    const email = req.params.email;
    const {newName, newEmail, newPhone, newPassword} = req.body
  
    const exist_order = db.users.findIndex(user =>  user.email == email || user.phone == email)
    const exist_user = db.users.findIndex(user =>  user.email == newEmail || user.phone == newPhone)

    if (exist_user !== -1) {
        return res.status(401).json({
            status: 401,
            message: "Email/Phone number already exist!!",
        })
    }

    if(exist_order !== -1) {
      db.users[exist_order].name = newName
      db.users[exist_order].email = newEmail
      db.users[exist_order].phone = newPhone
      db.users[exist_order].password = newPassword
  
      fs.writeFileSync('./db.json', JSON.stringify(db), () => {
        if (err) return console.log(err);
        console.log('writing to ' + fileName);
      })
  
      res.status(200).json({
        status: 200,
        message: "Success",
        data: {
          'user': db.users[exist_order]
        }
      })
    } else {
      res.status(401).json({
        status: 401,
        message: "User not found!!",
      })
    }
  
  })

/** End Users */

/** Sanpham */

// view sanpham tab
server.get('/auth/sanpham', (req, res) => {
    res.status(200).json({
        status: 200,
        data: {
        "category" : db.category
        }
    })
})

// Get a single category
server.get('/auth/sanpham/:category', ((req, res)=> {
    //let userdb = JSON.parse(fs.readFileSync('./database.json', 'UTF-8'));
        const category = req.params.category;
    
        const exist_category = db.category.findIndex(sanpham =>  sanpham.name == category)
        const result = db.category.filter(sanpham =>  sanpham.name == category)
        if (exist_category !== -1)
        {
            const status = 200
            return res.status(status).json({status, result})
        } else {
        return res.status(401).json({
        status: 401,
        message: "Can't find category!!",
        })
    }}))

// Get a single category child
server.get('/auth/sanpham/category/:name', ((req, res)=> {
//let userdb = JSON.parse(fs.readFileSync('./database.json', 'UTF-8'));
    const name = req.params.name;

    const exist_name = db.sanpham.findIndex(sanpham =>  sanpham.category == name)
    const result = db.sanpham.filter(sanpham =>  sanpham.category == name)
    if (exist_name !== -1)
    {
        const status = 200
        return res.status(status).json({status, result})
    } else {
    return res.status(401).json({
    status: 401,
    message: "Can't find product!!",
    })
}}))

// Get a single product
server.get('/auth/sanpham/product/:name', ((req, res)=> {
    //let userdb = JSON.parse(fs.readFileSync('./database.json', 'UTF-8'));
        const name = req.params.name;
    
        const exist_name = db.sanpham.findIndex(sanpham =>  sanpham.name == name)
        const result = db.sanpham.filter(sanpham =>  sanpham.name == name)
        if (exist_name !== -1)
        {
            const status = 200
            return res.status(status).json({status, result})
        } else {
        return res.status(401).json({
        status: 401,
        message: "Can't find product!!",
        })
    }}))

/** End Sanpham */

/** Sale off */

// view all sale off products
server.get('/auth/saleoff', (req, res) => {
  res.status(200).json({
      status: 200,
      data: {
      "category" : db.saleoff
      }
  })
})

// get sale off by search

server.post('/auth/saleoff', (req, res) => {
  const {name, gia, sale, category} = req.body

  const exist_id = db.saleoff.findIndex(so => so.name == name || so.gia == gia || so.sale == sale || so.category == category)
  const result = db.saleoff.filter(so => so.name == name || so.gia == gia || so.sale == sale || so.category == category)

  if(exist_id === -1) {
    return res.status(401).json({
      status: 401,
      message: "Product not found or not on sale!!",
    })
  } else {
    const status = 200
    return res.status(status).json({status, result})
  }
  
})

/** End Sale off */

/** Order */

//view all orders
server.get('/auth/orders', (req, res) => {
  res.status(200).json({
    status: 200,
    message: "Success",
    data: {
      "orders" : db.orders
    }
  })
})

//view order by id
server.get('/auth/orders/:id', (req, res) => {
  const order_id = req.params.id

  const exist_order = db.orders.findIndex(order => order.id == order_id)
  if(exist_order !== -1) {
      res.status(200).json({
            status: 200,
            data: {
              'orders': db.orders[exist_order]
            }
          })
    } else {
      return res.status(401).json({
        status: 401,
        message: "Order not found!!",
      })
    }
})

//add new order
server.post('/auth/orders', (req, res) => {
  const {productId, customerName, email, soluong} = req.body
  const exist_id = db.sanpham.findIndex(sp => sp.id === productId)

  if(exist_id === -1) {
    return res.status(401).json({
      status: 401,
      message: "Product not found!!",
    })
  }

  if (soluong <= 0) {
    soluong = 1
  }

  const order_sp = db.sanpham[exist_id]
  if(soluong <= order_sp.soluong && order_sp.soluong > 0) {
    const new_order = {
      'id': db.orders.length+1,
      productId,
      customerName,
      email,
      soluong,
      "timestamp": new Date().getTime()
    }
  
    db.orders.push(new_order);
    fs.writeFileSync('./db.json', JSON.stringify(db), () => {
      if (err) return console.log(err);
      console.log('writing to ' + fileName);
    })
    return res.status(200).json({
      status: 200,
      message: "Success",
      data: new_order
    })
  } else {
    return res.status(401).json({
      status: 401,
      message: "Not enough product in stock!!",
    })
  }
})

//delete order by id
server.delete('/auth/orders/:id', (req, res) => {
  const order_id = req.params.id

  const exist_order = db.orders.findIndex(order => order.id == order_id)
  if(exist_order !== -1) {
    db.orders.splice(exist_order, 1);

    fs.writeFileSync('./db.json', JSON.stringify(db), () => {
      if (err) return console.log(err);
      console.log('writing to ' + fileName);
    })

    return res.status(204).json({
      status: 204,
      message: "Success",
    })
  } else {
    return res.status(401).json({
      status: 401,
      message: "Order not found!!",
    })
  }

})

//update customer name
server.patch('/auth/orders/:id', (req, res) => {
  const order_id = req.params.id
  const customerName = req.body.customerName

  const exist_order = db.orders.findIndex(order => order.id == order_id)
  if(exist_order !== -1) {
    db.orders[exist_order].customerName = customerName

    fs.writeFileSync('./db.json', JSON.stringify(db), () => {
      if (err) return console.log(err);
      console.log('writing to ' + fileName);
    })

    res.status(200).json({
      status: 200,
      message: "Success",
      data: {
        'orders': db.orders[exist_order]
      }
    })
  } else {
    res.status(401).json({
      status: 401,
      message: "Order not found!!",
    })
  }

})

/** End Order */

server.use(router)

server.listen(PORT, () => {
  console.log('Run Auth API Server')
})